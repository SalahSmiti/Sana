<?php 
	/*Fonctions-modèle réalisant les requètes de gestion des contacts en base de données*/
	
	// liste_contact_bd : retourne la liste des informations pour chaque contact de l'utilisateur $id
	
	function EDTetu($login_etu) {
		require ("modele/connect.php") ; 
		//		WHERE E.login_etu=:login_etu AND E.id_grpe=C.id_grpe

		$sql="SELECT C.id_Creneau, C.tDeb, C.tFin, S.nom as Salle, M.nom as Matiere FROM Creneau C, Etudiant E, Salle S, Matiere M
				WHERE E.login_etu=:login_etu AND E.id_grpe=C.id_grpe AND C.id_salle=S.id_salle AND C.id_mat=M.id_mat;
		LIMIT 0,30;"; // LIMIT ne marche pas en MS SQL SERVER
		try {
			$commande = $pdo->prepare($sql);
			$commande->bindParam(':login_etu', $login_etu);
			$bool = $commande->execute();
			
			$C= array();
			//echo('bool vaut '.$bool);
			if ($bool) {
				while ($c = $commande->fetch()) {
					echo('DANS LA BOUBLEEE WHILE ');
					$C[] = $c; //stockage dans $C des enregistrements sélectionnés
				}	
			}
		}
		catch (PDOException $e) {
			echo utf8_encode("Echec de select : " . $e->getMessage() . "\n");
			die(); // On arrête tout.
		}
		return $C;
	}
?>
